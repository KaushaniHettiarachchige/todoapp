package com.example.taskmanagementapp

data class Task(val id: Int, val title: String, val content: String)

